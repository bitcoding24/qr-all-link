import math
from io import BytesIO
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

# =========================================================
# Streamlit 기본 설정
# =========================================================

st.set_page_config(
    page_title="전국 학사일정 GA 차이 분석",
    page_icon="🧬",
    layout="wide",
)

st.title("🧬 전국 학교 실제 학사일정 vs GA 최적 학사일정 차이 분석")
st.caption(
    "모든 학교의 실제 학사일정과 유전알고리즘이 만든 최적 학사일정을 비교하여, "
    "학교별 위험지수 차이를 구체적인 수치로 계산합니다."
)

# =========================================================
# 2025학년도 기본 국가공휴일
# 필요하면 다른 연도 공휴일을 여기에 추가하면 됩니다.
# =========================================================

NATIONAL_HOLIDAYS = {
    "2025-03-01": "삼일절",
    "2025-03-03": "삼일절 대체공휴일",
    "2025-05-05": "어린이날·부처님오신날",
    "2025-05-06": "대체공휴일",
    "2025-06-03": "대통령 선거일",
    "2025-06-06": "현충일",
    "2025-08-15": "광복절",
    "2025-10-03": "개천절",
    "2025-10-05": "추석 연휴",
    "2025-10-06": "추석",
    "2025-10-07": "추석 연휴",
    "2025-10-08": "추석 대체공휴일",
    "2025-10-09": "한글날",
    "2025-12-25": "성탄절",
    "2026-01-01": "신정",
    "2026-02-16": "설날 연휴",
    "2026-02-17": "설날",
    "2026-02-18": "설날 연휴",
}

# =========================================================
# 데이터 읽기 / 전처리
# =========================================================

def clean_text_columns(df: pd.DataFrame, cols: List[str]) -> pd.DataFrame:
    for col in cols:
        if col in df.columns:
            df[col] = df[col].fillna("").astype(str).str.strip()
    return df


@st.cache_data(show_spinner=False, max_entries=2)
def load_uploaded_files(file_bytes_and_names: List[Tuple[bytes, str]]) -> pd.DataFrame:
    dfs = []
    encodings = ["utf-8-sig", "cp949", "euc-kr", "utf-8"]

    for raw, name in file_bytes_and_names:
        temp = None
        last_error = None
        for enc in encodings:
            try:
                temp = pd.read_csv(BytesIO(raw), encoding=enc, low_memory=False)
                break
            except Exception as e:
                last_error = e
        if temp is None:
            raise ValueError(f"{name} 파일을 읽지 못했습니다. 마지막 오류: {last_error}")
        temp["원본파일명"] = name
        dfs.append(temp)

    if not dfs:
        return pd.DataFrame()

    df = pd.concat(dfs, ignore_index=True)
    df.columns = df.columns.str.strip()
    return df


@st.cache_data(show_spinner=False, max_entries=2)
def build_daily_school(df: pd.DataFrame, start_date: str, end_date: str) -> pd.DataFrame:
    df3 = df.copy()
    df3.columns = df3.columns.str.strip()

    required_cols = [
        "시도교육청코드", "시도교육청명", "행정표준코드", "학교명", "학교과정명",
        "수업공제일명", "학사일자", "행사명", "행사내용"
    ]
    missing = [c for c in required_cols if c not in df3.columns]
    if missing:
        raise ValueError(f"필수 열이 없습니다: {missing}")

    df3["학사일자"] = df3["학사일자"].astype(str).str.replace(r"\D", "", regex=True)
    df3["date"] = pd.to_datetime(df3["학사일자"], format="%Y%m%d", errors="coerce")
    df3 = df3.dropna(subset=["date"]).copy()

    start_dt = pd.to_datetime(start_date)
    end_dt = pd.to_datetime(end_date)
    df3 = df3[(df3["date"] >= start_dt) & (df3["date"] <= end_dt)].copy()

    text_cols = [
        "시도교육청코드", "시도교육청명", "행정표준코드", "학교명", "학년도",
        "주야과정명", "학교과정명", "수업공제일명", "행사명", "행사내용", "수정일자", "원본파일명"
    ]
    df3 = clean_text_columns(df3, text_cols)

    df3["is_rest_event"] = df3["수업공제일명"].isin(["휴업일", "공휴일"])
    df3["is_public_holiday_from_data"] = df3["수업공제일명"].eq("공휴일")

    vacation_keywords = "방학|여름방학|겨울방학|봄방학|학년말방학|학기말방학|동계방학|하계방학|방학식"
    df3["is_vacation_event"] = (
        df3["행사명"].fillna("").str.contains(vacation_keywords, regex=True)
        | df3["행사내용"].fillna("").str.contains(vacation_keywords, regex=True)
    )

    unit_cols = ["시도교육청코드", "시도교육청명", "행정표준코드", "학교명", "학교과정명"]

    def join_unique(values):
        values = [str(v).strip() for v in values if str(v).strip()]
        return ", ".join(sorted(set(values)))

    daily_school = (
        df3.groupby(unit_cols + ["date"], as_index=False)
        .agg(
            is_rest_event=("is_rest_event", "max"),
            is_public_holiday_from_data=("is_public_holiday_from_data", "max"),
            is_vacation_day=("is_vacation_event", "max"),
            행사개수=("행사명", "size"),
            행사명_목록=("행사명", join_unique),
            수업공제일명_목록=("수업공제일명", join_unique),
        )
    )

    daily_school["분석단위ID"] = (
        daily_school["시도교육청코드"].astype(str) + "_"
        + daily_school["행정표준코드"].astype(str) + "_"
        + daily_school["학교과정명"].astype(str)
    )
    daily_school["학교표시명"] = daily_school["학교명"] + " (" + daily_school["학교과정명"] + ")"
    daily_school["is_term_rest_day"] = daily_school["is_rest_event"] & ~daily_school["is_vacation_day"]
    return daily_school


@st.cache_data(show_spinner=False, max_entries=2)
def build_calendar(daily_school: pd.DataFrame, start_date: str, end_date: str) -> Tuple[pd.DataFrame, pd.DataFrame]:
    start_dt = pd.to_datetime(start_date)
    end_dt = pd.to_datetime(end_date)
    all_dates = pd.DataFrame({"date": pd.date_range(start_dt, end_dt, freq="D")})

    unit_cols = [
        "시도교육청코드", "시도교육청명", "행정표준코드", "학교명", "학교과정명", "분석단위ID", "학교표시명"
    ]
    units = daily_school[unit_cols].drop_duplicates().copy()
    calendar = units.merge(all_dates, how="cross")

    merge_cols = [
        "분석단위ID", "date", "is_rest_event", "is_public_holiday_from_data",
        "is_vacation_day", "is_term_rest_day", "행사개수", "행사명_목록", "수업공제일명_목록"
    ]
    calendar = calendar.merge(daily_school[merge_cols], on=["분석단위ID", "date"], how="left")

    for col in ["is_rest_event", "is_public_holiday_from_data", "is_vacation_day", "is_term_rest_day"]:
        calendar[col] = calendar[col].fillna(False).astype(bool)

    calendar["행사개수"] = calendar["행사개수"].fillna(0).astype(int)
    calendar["행사명_목록"] = calendar["행사명_목록"].fillna("")
    calendar["수업공제일명_목록"] = calendar["수업공제일명_목록"].fillna("")

    calendar["요일번호"] = calendar["date"].dt.weekday
    calendar["is_weekend"] = calendar["요일번호"] >= 5
    calendar["date_str"] = calendar["date"].dt.strftime("%Y-%m-%d")

    calendar["is_national_holiday"] = calendar["date_str"].isin(NATIONAL_HOLIDAYS.keys())
    calendar["national_holiday_name"] = calendar["date_str"].map(NATIONAL_HOLIDAYS).fillna("")
    calendar["is_public_holiday"] = calendar["is_public_holiday_from_data"] | calendar["is_national_holiday"]

    # 방학 기간 확장: 방학 시작 신호부터 개학 전까지를 방학으로 처리
    calendar["is_vacation_day_raw"] = calendar["is_vacation_day"].copy()
    vacation_start_pattern = "방학식|방학시작|방학 시작|여름방학|겨울방학|봄방학|학년말방학|학기말방학|동계방학|하계방학|방학"
    vacation_end_pattern = "개학|개학식|등교개학|수업시작|수업 시작"

    def expand_vacation_periods(group: pd.DataFrame) -> pd.Series:
        group = group.sort_values("date").copy()
        event_text = (
            group["행사명_목록"].fillna("").astype(str)
            + " "
            + group["수업공제일명_목록"].fillna("").astype(str)
        )
        raw_vacation = group["is_vacation_day_raw"].to_numpy(dtype=bool)
        start_flag = event_text.str.contains(vacation_start_pattern, regex=True, na=False).to_numpy(dtype=bool)
        end_flag = event_text.str.contains(vacation_end_pattern, regex=True, na=False).to_numpy(dtype=bool)

        result = []
        in_vacation = False
        for raw, start, end in zip(raw_vacation, start_flag, end_flag):
            if end:
                in_vacation = False
                result.append(False)
                continue
            if raw or start:
                in_vacation = True
            result.append(in_vacation)
        return pd.Series(result, index=group.index)

    calendar["is_vacation_day"] = (
        calendar.groupby("분석단위ID", group_keys=False)
        .apply(expand_vacation_periods)
        .astype(bool)
    )
    calendar["is_inferred_vacation_day"] = calendar["is_vacation_day"] & ~calendar["is_vacation_day_raw"]

    calendar["is_main_analysis_day"] = ~calendar["is_vacation_day"]

    # 실제 위험지수 분석과 기준을 맞춘다.
    # 고정 휴업일: 주말 + 국가/공휴일
    # 재배치 대상: 방학·주말·공휴일을 제외한 평일 중 수업공제일명에 '휴업일'이 있는 날
    calendar["is_fixed_rest_day"] = calendar["is_main_analysis_day"] & (calendar["is_weekend"] | calendar["is_public_holiday"])
    calendar["is_school_rest_event"] = calendar["수업공제일명_목록"].fillna("").astype(str).str.contains("휴업일", na=False)
    calendar["is_actual_movable_rest"] = (
        calendar["is_main_analysis_day"]
        & ~calendar["is_weekend"]
        & ~calendar["is_public_holiday"]
        & calendar["is_school_rest_event"]
    )
    calendar["is_actual_rest_day"] = calendar["is_fixed_rest_day"] | calendar["is_actual_movable_rest"]
    calendar["is_study_day"] = calendar["is_main_analysis_day"] & ~calendar["is_actual_rest_day"]
    calendar["is_candidate_day"] = calendar["is_main_analysis_day"] & ~calendar["is_weekend"] & ~calendar["is_public_holiday"]

    vacation_check = (
        calendar.groupby([
            "시도교육청명", "행정표준코드", "학교명", "학교과정명", "분석단위ID", "학교표시명"
        ])
        .agg(
            전체일수=("date", "nunique"),
            방학일수=("is_vacation_day", "sum"),
            추론방학일수=("is_inferred_vacation_day", "sum"),
            공통고정휴업일수=("is_fixed_rest_day", "sum"),
            실제재배치대상휴업일수=("is_actual_movable_rest", "sum"),
            배치가능일수=("is_candidate_day", "sum"),
            분석일수=("is_main_analysis_day", "sum"),
        )
        .reset_index()
    )
    return calendar, vacation_check

# =========================================================
# 기억점수 계산
# =========================================================

def simulate_by_rest_mask(
    base: pd.DataFrame,
    rest_mask: np.ndarray,
    M0: float,
    K1: float,
    C: float,
    D: float,
    R: float,
    high_risk_threshold: float,
    objective: str = "all",
) -> Tuple[pd.DataFrame, Dict[str, float]]:
    df = base.sort_values("date").copy().reset_index(drop=True)
    main_analysis = df["is_main_analysis_day"].to_numpy(dtype=bool)

    n = len(df)
    memory_scores = np.full(n, np.nan, dtype=float)
    risk_scores = np.full(n, np.nan, dtype=float)

    memory = M0
    p = 0

    for i in range(n):
        if not main_analysis[i]:
            memory = M0
            p = 0
            continue

        if rest_mask[i]:
            p += 1
            k = K1 / ((1 + C * p) ** D)
            memory = memory * math.exp(-k)
        else:
            memory = memory + R * (M0 - memory)
            p = 0

        memory = max(0.0, min(M0, memory))
        memory_scores[i] = memory
        risk_scores[i] = M0 - memory

    df["memory_score"] = memory_scores
    df["risk_score"] = risk_scores

    analysis = df[df["is_main_analysis_day"]].copy()
    analysis_idx = analysis.index.to_numpy()

    if objective == "study":
        score_data = analysis[~rest_mask[analysis_idx]]
    else:
        score_data = analysis

    avg_risk = float(score_data["risk_score"].mean()) if len(score_data) else 0.0
    high_ratio = float((analysis["risk_score"] >= high_risk_threshold).mean() * 100) if len(analysis) else 0.0
    final_risk = 0.7 * avg_risk + 0.3 * high_ratio

    return df, {
        "avg_risk_score": avg_risk,
        "high_risk_day_ratio": high_ratio,
        "final_risk_index": final_risk,
        "max_risk_score": float(analysis["risk_score"].max()) if len(analysis) else 0.0,
        "min_memory_score": float(analysis["memory_score"].min()) if len(analysis) else M0,
    }


def get_masks_for_school(one_school: pd.DataFrame) -> Dict[str, np.ndarray]:
    df = one_school.sort_values("date").copy().reset_index(drop=True)
    fixed_rest = df["is_fixed_rest_day"].to_numpy(dtype=bool)
    actual_movable = df["is_actual_movable_rest"].to_numpy(dtype=bool)
    candidate = df["is_candidate_day"].to_numpy(dtype=bool)
    actual_rest = fixed_rest | actual_movable

    return {
        "fixed_rest": fixed_rest,
        "actual_movable": actual_movable,
        "candidate": candidate,
        "actual_rest": actual_rest,
    }

# =========================================================
# 유전 알고리즘
# =========================================================

def repair_genome(g: np.ndarray, n_rest: int, rng: np.random.Generator) -> np.ndarray:
    g = g.copy()
    cnt = int(g.sum())
    if cnt > n_rest:
        ones = np.where(g == 1)[0]
        g[rng.choice(ones, size=cnt - n_rest, replace=False)] = 0
    elif cnt < n_rest:
        zeros = np.where(g == 0)[0]
        if len(zeros) > 0:
            g[rng.choice(zeros, size=min(n_rest - cnt, len(zeros)), replace=False)] = 1
    return g


def make_random_genome(n_candidate: int, n_rest: int, rng: np.random.Generator) -> np.ndarray:
    g = np.zeros(n_candidate, dtype=np.int8)
    if n_rest > 0:
        idx = rng.choice(np.arange(n_candidate), size=n_rest, replace=False)
        g[idx] = 1
    return g


def tournament_select(pop: List[np.ndarray], fits: List[float], rng: np.random.Generator, k: int = 3) -> np.ndarray:
    k = min(k, len(pop))
    idxs = rng.choice(np.arange(len(pop)), size=k, replace=False)
    best = min(idxs, key=lambda i: fits[i])
    return pop[best].copy()


def crossover(p1: np.ndarray, p2: np.ndarray, n_rest: int, rng: np.random.Generator, cx_rate: float) -> Tuple[np.ndarray, np.ndarray]:
    if len(p1) <= 1 or rng.random() > cx_rate:
        return p1.copy(), p2.copy()
    pt = int(rng.integers(1, len(p1)))
    c1 = np.concatenate([p1[:pt], p2[pt:]]).astype(np.int8)
    c2 = np.concatenate([p2[:pt], p1[pt:]]).astype(np.int8)
    return repair_genome(c1, n_rest, rng), repair_genome(c2, n_rest, rng)


def mutate(g: np.ndarray, n_rest: int, rng: np.random.Generator, mut_rate: float) -> np.ndarray:
    g = g.copy()
    if len(g) == 0:
        return g
    flips = rng.random(len(g)) < mut_rate
    g[flips] = 1 - g[flips]
    return repair_genome(g, n_rest, rng)


def run_ga_for_school(
    one_school: pd.DataFrame,
    M0: float,
    K1: float,
    C: float,
    D: float,
    R: float,
    high_risk_threshold: float,
    objective: str,
    population_size: int,
    generations: int,
    mutation_rate: float,
    crossover_rate: float,
    elite_size: int,
    seed: int,
) -> Dict[str, object]:
    base = one_school.sort_values("date").copy().reset_index(drop=True)
    masks = get_masks_for_school(base)

    fixed_rest = masks["fixed_rest"]
    actual_movable = masks["actual_movable"]
    actual_rest = masks["actual_rest"]
    candidate = masks["candidate"]
    candidate_idx = np.where(candidate)[0]
    n_rest = int(actual_movable.sum())

    actual_df, actual_metrics = simulate_by_rest_mask(
        base, actual_rest, M0, K1, C, D, R, high_risk_threshold, objective
    )

    if n_rest > len(candidate_idx):
        raise ValueError("재배치 대상 휴업일 수가 배치 가능 일수보다 많습니다.")

    if n_rest == 0:
        optimized_movable = np.zeros(len(base), dtype=bool)
        opt_rest = fixed_rest.copy()
        opt_df, opt_metrics = simulate_by_rest_mask(
            base, opt_rest, M0, K1, C, D, R, high_risk_threshold, objective
        )
        history = []
    else:
        rng = np.random.default_rng(seed)

        def genome_to_rest_mask(g: np.ndarray) -> np.ndarray:
            rest = fixed_rest.copy()
            chosen_idx = candidate_idx[g.astype(bool)]
            rest[chosen_idx] = True
            return rest

        def fitness(g: np.ndarray) -> float:
            rest = genome_to_rest_mask(g)
            _, metrics = simulate_by_rest_mask(base, rest, M0, K1, C, D, R, high_risk_threshold, objective)
            return metrics["final_risk_index"]

        pop = [make_random_genome(len(candidate_idx), n_rest, rng) for _ in range(population_size)]
        fits = [fitness(g) for g in pop]
        history = []

        for _ in range(generations):
            order = np.argsort(fits)
            new_pop = [pop[i].copy() for i in order[: min(elite_size, len(pop))]]

            while len(new_pop) < population_size:
                p1 = tournament_select(pop, fits, rng)
                p2 = tournament_select(pop, fits, rng)
                c1, c2 = crossover(p1, p2, n_rest, rng, crossover_rate)
                new_pop.append(mutate(c1, n_rest, rng, mutation_rate))
                if len(new_pop) < population_size:
                    new_pop.append(mutate(c2, n_rest, rng, mutation_rate))

            pop = new_pop
            fits = [fitness(g) for g in pop]
            history.append(float(min(fits)))

        best_i = int(np.argmin(fits))
        best_g = pop[best_i]
        opt_rest = genome_to_rest_mask(best_g)
        opt_df, opt_metrics = simulate_by_rest_mask(
            base, opt_rest, M0, K1, C, D, R, high_risk_threshold, objective
        )

        optimized_movable = np.zeros(len(base), dtype=bool)
        optimized_movable[candidate_idx[best_g.astype(bool)]] = True

    actual_set = set(base.loc[actual_movable, "date"].dt.strftime("%Y-%m-%d"))
    opt_set = set(base.loc[optimized_movable, "date"].dt.strftime("%Y-%m-%d"))
    inter = len(actual_set & opt_set)
    union = len(actual_set | opt_set)

    candidate_idx = np.where(candidate)[0]
    date_similarity = float((actual_movable[candidate_idx] == optimized_movable[candidate_idx]).mean() * 100) if len(candidate_idx) else 100.0
    jaccard = inter / union * 100 if union else 100.0

    actual_risk = actual_metrics["final_risk_index"]
    opt_risk = opt_metrics["final_risk_index"]
    diff = actual_risk - opt_risk
    diff_rate = diff / actual_risk * 100 if actual_risk else 0.0

    row = base.iloc[0]
    return {
        "시도교육청명": row["시도교육청명"],
        "학교명": row["학교명"],
        "학교과정명": row["학교과정명"],
        "분석단위ID": row["분석단위ID"],
        "학교표시명": row["학교표시명"],
        "분석일수": int(base["is_main_analysis_day"].sum()),
        "방학일수": int(base["is_vacation_day"].sum()),
        "배치가능일수": int(candidate.sum()),
        "공통고정휴업일수": int(fixed_rest.sum()),
        "실제재배치대상휴업일수": int(actual_movable.sum()),
        "최적재배치대상휴업일수": int(optimized_movable.sum()),
        "겹치는휴업일수": int(inter),
        "실제최종위험지수": actual_risk,
        "최적최종위험지수": opt_risk,
        "위험지수차이_실제_minus_최적": diff,
        "위험지수차이율_percent": diff_rate,
        "실제평균위험점수": actual_metrics["avg_risk_score"],
        "최적평균위험점수": opt_metrics["avg_risk_score"],
        "평균위험점수차이": actual_metrics["avg_risk_score"] - opt_metrics["avg_risk_score"],
        "실제고위험일비율": actual_metrics["high_risk_day_ratio"],
        "최적고위험일비율": opt_metrics["high_risk_day_ratio"],
        "고위험일비율차이": actual_metrics["high_risk_day_ratio"] - opt_metrics["high_risk_day_ratio"],
        "날짜일치율_percent": date_similarity,
        "휴업일Jaccard유사도_percent": jaccard,
        "GA최종세대최저값": history[-1] if history else opt_risk,
    }

# =========================================================
# 파일 다운로드 보조
# =========================================================

def to_excel_bytes(dfs: Dict[str, pd.DataFrame]) -> bytes:
    output = BytesIO()
    with pd.ExcelWriter(output, engine="openpyxl") as writer:
        for sheet_name, df in dfs.items():
            df.to_excel(writer, sheet_name=sheet_name[:31], index=False)
    return output.getvalue()

# =========================================================
# 사이드바 설정
# =========================================================

with st.sidebar:
    st.header("1. 데이터 업로드")
    uploaded_files = st.file_uploader("월별 학사일정 CSV 파일", type=["csv"], accept_multiple_files=True)

    st.header("2. 분석 기간")
    start_date = st.date_input("시작일", value=pd.to_datetime("2025-03-01"))
    end_date = st.date_input("종료일", value=pd.to_datetime("2026-02-28"))

    st.header("3. 기억 모델")
    M0 = st.number_input("최대 기억점수 M0", value=100.0, min_value=1.0, step=1.0)
    K1 = st.number_input("초기 망각 속도 K1", value=0.35, min_value=0.0, step=0.01)
    C = st.number_input("k 감소 상수 C", value=0.5, min_value=0.0, step=0.1)
    D = st.number_input("k 감소 형태 D", value=1.0, min_value=0.1, step=0.1)
    R = st.number_input("수업일 회복률 R", value=0.30, min_value=0.0, max_value=1.0, step=0.05)
    high_risk_threshold = st.number_input("고위험 기준 점수", value=60.0, min_value=0.0, max_value=100.0, step=5.0)

    st.header("4. GA 설정")
    objective = st.selectbox("목적함수", ["all", "study"], format_func=lambda x: "모든 분석일 평균 위험" if x == "all" else "수업일 평균 위험")
    population_size = st.number_input("개체 수", value=40, min_value=10, max_value=300, step=10)
    generations = st.number_input("세대 수", value=100, min_value=10, max_value=2000, step=10)
    mutation_rate = st.number_input("돌연변이율", value=0.02, min_value=0.0, max_value=0.5, step=0.01)
    crossover_rate = st.number_input("교차율", value=0.9, min_value=0.0, max_value=1.0, step=0.05)
    elite_size = st.number_input("엘리트 보존 수", value=3, min_value=1, max_value=20, step=1)
    seed = st.number_input("랜덤 시드", value=42, min_value=0, step=1)

    st.header("5. 일괄 실행 범위")
    max_schools = st.number_input("최대 실행 학교 수", value=100, min_value=0, step=10, help="0이면 필터된 모든 학교를 실행합니다.")

    prepare_btn = st.button("📦 데이터 준비", type="primary", use_container_width=True)

if prepare_btn:
    if not uploaded_files:
        st.error("먼저 CSV 파일을 업로드하세요.")
    else:
        with st.spinner("CSV 파일을 읽는 중..."):
            file_payload = [(f.getvalue(), f.name) for f in uploaded_files]
            raw_df = load_uploaded_files(file_payload)
        with st.spinner("학교-과정-날짜 단위로 정리하는 중..."):
            daily_school = build_daily_school(raw_df, str(start_date), str(end_date))
        with st.spinner("전체 날짜표를 만드는 중..."):
            calendar, vacation_check = build_calendar(daily_school, str(start_date), str(end_date))

        st.session_state["calendar"] = calendar
        st.session_state["vacation_check"] = vacation_check
        if "batch_results" in st.session_state:
            del st.session_state["batch_results"]
        st.success("데이터 준비 완료!")

if "calendar" not in st.session_state:
    st.info("왼쪽에서 CSV를 업로드하고 데이터 준비를 먼저 실행하세요.")
    st.stop()

calendar = st.session_state["calendar"].copy()

unit_table = (
    calendar[["분석단위ID", "시도교육청명", "학교명", "학교과정명", "학교표시명"]]
    .drop_duplicates()
    .sort_values(["시도교육청명", "학교명"])
)

# =========================================================
# 필터
# =========================================================

st.subheader("🔎 일괄 실행할 학교 필터")
f1, f2, f3 = st.columns([2.2, 1.2, 1.2])
with f1:
    query = st.text_input("학교명 검색", placeholder="비워두면 전체")
with f2:
    regions = ["전체"] + sorted(unit_table["시도교육청명"].dropna().unique().tolist())
    region = st.selectbox("시도교육청", regions)
with f3:
    courses = ["전체"] + sorted(unit_table["학교과정명"].dropna().unique().tolist())
    course = st.selectbox("학교과정", courses)

filtered_units = unit_table.copy()
if query.strip():
    filtered_units = filtered_units[filtered_units["학교명"].str.contains(query.strip(), case=False, na=False)]
if region != "전체":
    filtered_units = filtered_units[filtered_units["시도교육청명"] == region]
if course != "전체":
    filtered_units = filtered_units[filtered_units["학교과정명"] == course]

if max_schools > 0:
    run_units = filtered_units.head(int(max_schools)).copy()
else:
    run_units = filtered_units.copy()

st.caption(f"필터 결과 {len(filtered_units):,}개 중 이번 실행 대상 {len(run_units):,}개")

run_batch_btn = st.button("🧬 선택 범위 전체 GA 실행", type="primary")

if run_batch_btn:
    if run_units.empty:
        st.error("실행할 학교가 없습니다.")
    else:
        rows = []
        errors = []
        progress = st.progress(0, text="일괄 GA 실행 준비 중...")

        for idx, unit in enumerate(run_units.itertuples(index=False), start=1):
            unit_id = unit.분석단위ID
            school_name = unit.학교표시명
            one_school = calendar[calendar["분석단위ID"] == unit_id].sort_values("date").copy().reset_index(drop=True)

            try:
                row = run_ga_for_school(
                    one_school=one_school,
                    M0=float(M0),
                    K1=float(K1),
                    C=float(C),
                    D=float(D),
                    R=float(R),
                    high_risk_threshold=float(high_risk_threshold),
                    objective=objective,
                    population_size=int(population_size),
                    generations=int(generations),
                    mutation_rate=float(mutation_rate),
                    crossover_rate=float(crossover_rate),
                    elite_size=int(elite_size),
                    seed=int(seed) + idx,
                )
                rows.append(row)
            except Exception as e:
                errors.append({"학교표시명": school_name, "오류": str(e)})

            progress.progress(idx / len(run_units), text=f"{idx}/{len(run_units)} 실행 중 · {school_name}")

        progress.empty()
        result_df = pd.DataFrame(rows)
        error_df = pd.DataFrame(errors)
        st.session_state["batch_results"] = result_df
        st.session_state["batch_errors"] = error_df
        st.success(f"일괄 실행 완료: 성공 {len(result_df):,}개, 오류 {len(error_df):,}개")

if "batch_results" not in st.session_state:
    st.info("일괄 GA 실행 버튼을 누르면 학교별 위험지수 차이 데이터가 생성됩니다.")
    st.stop()

result_df = st.session_state["batch_results"].copy()
error_df = st.session_state.get("batch_errors", pd.DataFrame()).copy()

if result_df.empty:
    st.warning("결과가 비어 있습니다.")
    st.stop()

# =========================================================
# 결과 요약
# =========================================================

st.subheader("📌 전체 차이 수치 요약")

mean_diff = result_df["위험지수차이_실제_minus_최적"].mean()
median_diff = result_df["위험지수차이_실제_minus_최적"].median()
max_diff = result_df["위험지수차이_실제_minus_최적"].max()
min_diff = result_df["위험지수차이_실제_minus_최적"].min()

c1, c2, c3, c4, c5 = st.columns(5)
c1.metric("분석 학교 수", f"{len(result_df):,}")
c2.metric("평균 차이", f"{mean_diff:.3f}")
c3.metric("중앙값 차이", f"{median_diff:.3f}")
c4.metric("최대 + 차이", f"{max_diff:.3f}")
c5.metric("최대 - 차이", f"{min_diff:.3f}")

st.caption(
    "위험지수차이 = 실제 최종위험지수 - GA 최적 최종위험지수입니다. "
    "값이 +이면 실제 일정의 위험지수가 더 높고, 값이 -이면 실제 일정의 위험지수가 GA 결과보다 낮다는 뜻입니다."
)

# =========================================================
# 그래프
# =========================================================

st.subheader("📊 위험지수 차이 시각화")
g1, g2 = st.columns(2)

with g1:
    fig_hist = px.histogram(
        result_df,
        x="위험지수차이_실제_minus_최적",
        nbins=40,
        title="학교별 위험지수 차이 분포",
        labels={"위험지수차이_실제_minus_최적": "위험지수차이 = 실제 - 최적"},
    )
    fig_hist.add_vline(x=0, line_dash="dash", annotation_text="차이 0")
    st.plotly_chart(fig_hist, use_container_width=True)

with g2:
    fig_scatter = px.scatter(
        result_df,
        x="실제최종위험지수",
        y="최적최종위험지수",
        color="위험지수차이_실제_minus_최적",
        hover_name="학교표시명",
        title="실제 위험지수 vs GA 최적 위험지수",
        labels={
            "실제최종위험지수": "실제 최종위험지수",
            "최적최종위험지수": "GA 최적 최종위험지수",
            "위험지수차이_실제_minus_최적": "차이",
        },
    )
    min_v = min(result_df["실제최종위험지수"].min(), result_df["최적최종위험지수"].min())
    max_v = max(result_df["실제최종위험지수"].max(), result_df["최적최종위험지수"].max())
    fig_scatter.add_trace(go.Scatter(x=[min_v, max_v], y=[min_v, max_v], mode="lines", name="y=x", line=dict(dash="dash")))
    st.plotly_chart(fig_scatter, use_container_width=True)

b1, b2 = st.columns(2)
with b1:
    top_plus = result_df.sort_values("위험지수차이_실제_minus_최적", ascending=False).head(20)
    fig_plus = px.bar(
        top_plus.sort_values("위험지수차이_실제_minus_최적"),
        x="위험지수차이_실제_minus_최적",
        y="학교표시명",
        orientation="h",
        title="위험지수차이 + 상위 20개 학교",
        labels={"위험지수차이_실제_minus_최적": "차이"},
    )
    st.plotly_chart(fig_plus, use_container_width=True)

with b2:
    top_minus = result_df.sort_values("위험지수차이_실제_minus_최적", ascending=True).head(20)
    fig_minus = px.bar(
        top_minus.sort_values("위험지수차이_실제_minus_최적", ascending=False),
        x="위험지수차이_실제_minus_최적",
        y="학교표시명",
        orientation="h",
        title="위험지수차이 - 하위 20개 학교",
        labels={"위험지수차이_실제_minus_최적": "차이"},
    )
    fig_minus.add_vline(x=0, line_dash="dash")
    st.plotly_chart(fig_minus, use_container_width=True)

st.subheader("🗺️ 시도교육청별 평균 차이")
region_summary = (
    result_df.groupby("시도교육청명")
    .agg(
        학교수=("분석단위ID", "count"),
        평균위험지수차이=("위험지수차이_실제_minus_최적", "mean"),
        중앙값위험지수차이=("위험지수차이_실제_minus_최적", "median"),
        평균차이율=("위험지수차이율_percent", "mean"),
    )
    .reset_index()
    .sort_values("평균위험지수차이", ascending=False)
)
fig_region = px.bar(
    region_summary,
    x="평균위험지수차이",
    y="시도교육청명",
    orientation="h",
    hover_data=["학교수", "중앙값위험지수차이", "평균차이율"],
    title="시도교육청별 평균 위험지수차이",
)
fig_region.add_vline(x=0, line_dash="dash")
st.plotly_chart(fig_region, use_container_width=True)

# =========================================================
# 결과 표 / 다운로드
# =========================================================

st.subheader("📋 학교별 차이 데이터")

sort_col = st.selectbox(
    "정렬 기준",
    [
        "위험지수차이_실제_minus_최적",
        "위험지수차이율_percent",
        "실제최종위험지수",
        "최적최종위험지수",
        "날짜일치율_percent",
        "휴업일Jaccard유사도_percent",
    ],
)
ascending = st.checkbox("오름차순", value=False)
show_df = result_df.sort_values(sort_col, ascending=ascending).copy()
st.dataframe(show_df, use_container_width=True, height=460)

csv_bytes = result_df.to_csv(index=False, encoding="utf-8-sig").encode("utf-8-sig")
st.download_button(
    "CSV 다운로드",
    data=csv_bytes,
    file_name="학교별_GA최적일정_위험지수차이.csv",
    mime="text/csv",
)

excel_bytes = to_excel_bytes({
    "학교별차이데이터": result_df,
    "시도교육청별요약": region_summary,
    "오류목록": error_df,
})
st.download_button(
    "엑셀 다운로드",
    data=excel_bytes,
    file_name="학교별_GA최적일정_위험지수차이.xlsx",
    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
)

if not error_df.empty:
    with st.expander("오류 목록", expanded=False):
        st.dataframe(error_df, use_container_width=True)